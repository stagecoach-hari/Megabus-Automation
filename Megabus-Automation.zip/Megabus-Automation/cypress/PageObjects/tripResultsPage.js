/// <reference types="cypress" />



class tripResultsPage {
    tickets() {
    return cy.xpath('//div[contains(@class, "ticket__head")]/a');
}
   sortRapper(){
       return cy.get('.sort-select-wrapper')
   }

   InboundBanner(){
       return cy.get('.sr-journey-summary__date > strong')
   }

   outBoundReserveSeat() {
    cy.get(".panel.panel-default.ticket")
        //.should('have.css', '.col-xs-12.ticket__facilities')
        //.contains('Add to basket').click()
        // cy.get("[data-index]").find('#heading1')

        .each(function ($el, index, $list) {
            const seat = $el.find(".col-xs-12.ticket__facilities").text()
            if (seat.includes("reservation available")) {
                //cy.log($el.text().click())
                $el.find(".btn.btn-sm.btn-block.btn-primary").trigger("click");
                //$el.click()
            }
        })

}

    inBoundReserveSeat() {
    
        cy.get(".panel.panel-default.ticket")
        //.should('have.css', '.col-xs-12.ticket__facilities')
        //.contains('Add to basket').click()
        // cy.get("[data-index]").find('#heading1')

        .each(function ($el, index, $list) {
            const seat = $el.find(".col-xs-12.ticket__facilities").text()
            if (seat.includes("reservation available")) {
                //cy.log($el.text().click())
                $el.find(".btn.btn-sm.btn-block.btn-primary").trigger("click");
                //$el.click()
            }
        })

}


  //cy.get('.btn.btn-sm.btn-block.btn-primary').should('contain.text', 'Select return ticket' )
  //.contains(".col-xs-12.ticket__facilities").first().click()
//}

}
export default tripResultsPage