/// <reference types="cypress" />
class homePage {

    AcceptCookie() {
       return cy.get('form > .btn');
    }
    
    MegabusLabel(){
        return cy.get('svg');
    }

    From(){
        return cy.get('#startingAt');
    }

    To(){
        return cy.get('#goingTo')
    }
    enterOrigin() {
        return cy.get(".typeahead__selected > span:nth-child(1)");
    }
    enterDestination() {
        return cy.get(".typeahead__selected > span:nth-child(1)");
    }
    leavingDate() {
        return cy.get("#mat-input-0")
    }
    moveToNextMonth() {
        return cy.get(".mat-calendar-next-button")
    }
    selectLeavingDate() {
        return cy.get(".mat-calendar-body-cell-content").contains('1')
    }
    selectReturnDate() {
        return cy.get(".mat-calendar-body-cell-content").contains('2')
    }
    returnDate() {
        return cy.get("#mat-input-1")
    }
    findTickets() {
        return cy.get("#findTickets")
    }

}
    export default homePage