/// <reference types="cypress" />

class seatReservationPage {

selectReserveSeat(){
   return cy.contains('.seat.seatPart.seat-plan__vehiclePart[aria-label*=£]').click();
  // cy.get('.seat.seatPart.seat-plan__vehiclePart[role=button]')
           // .each(function ($el, index, $list) {
              //  $el.find(".seat.seatPart.seat-plan__vehiclePart[aria-label*=£]").click()
            }
          // )}



continue(){
   return cy.get('.btn').click();
}

reservationLable(){
    return cy.get('h1')
}

}
export default seatReservationPage