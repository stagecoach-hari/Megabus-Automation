/// <reference types="Cypress" />

import homePage from "../../PageObjects/homePage";
import tripResultsPage from "../../PageObjects/tripResultsPage";

const Home = new homePage()



describe('Plan a journey', () => {
    beforeEach(() =>{
        cy.visit('/')
    })
    
    it('Search any valid journeys', () => {
        // If the device is detected as mobile then use the burger menu to show the mega-menu.
        Home.AcceptCookie().click()
        Home.From().type('Man');
        Home.enterOrigin().click();
        Home.To().type('bir');
        cy.wait(1000)
        Home.enterDestination().contains('Birmingham').click();
        cy.wait(2000)
        Home.leavingDate().click();
        cy.wait(2000)
        Home.moveToNextMonth().click();
        Home.selectLeavingDate().click();
        
        Home.returnDate().click();
        Home.selectReturnDate().click();
        Home.findTickets().click();

    })
    it('Verify the journey has trip results',() =>{
     
        const trips = new tripResultsPage()
        
        trips.sortRapper().should('be.visible')
        
    })
})