/// <reference types="Cypress" />

import homePage from "../../PageObjects/homePage";
import tripResultsPage from "../../PageObjects/tripResultsPage";
import seatReservationPage from "../../PageObjects/seatReservationPage";

const Home = new homePage()
const trips = new tripResultsPage()
const reservationSeat = new seatReservationPage()



describe('Plan a journey', () => {
    it('visit wesite',() => {
        
            cy.visit('/')
    })
    
    it('Search any valid journeys', () => {

        Home.AcceptCookie().click()
        Home.From().type('Man');
        Home.enterOrigin().click();
        Home.To().type('bir');
        cy.wait(1000)
        Home.enterDestination().contains('Birmingham').click();
        cy.wait(1000)
        Home.leavingDate().click();
        cy.wait(2000)
        Home.moveToNextMonth().click();
        Home.selectLeavingDate().click();
        
        Home.returnDate().click();
        Home.selectReturnDate().click();
        Home.findTickets().click();

    })
    it('Verify the journey has trip results',() =>{
     
        trips.sortRapper().should('be.visible') 
        trips.outBoundReserveSeat();
        trips.InboundBanner().should('be.visible');
        trips.inBoundReserveSeat();
        cy.wait(2000)
        reservationSeat.reservationLable().should('be.visible');
        //reservationSeat.selectReserveSeat();
        //reservationSeat.continue();

    })
    it('add reserve seat', () =>{
      
       //// reservationSeat.reservationLable().should('be.visible')
       // reservationSeat.selectReserveSeat();
        //reservationSeat.continue();
    })
})

